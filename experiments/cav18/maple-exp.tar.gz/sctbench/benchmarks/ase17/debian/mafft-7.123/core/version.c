#include "mltaln.h"

int main()
{
	fprintf( stdout, VERSION"\n" );
	return( 0 );
}
