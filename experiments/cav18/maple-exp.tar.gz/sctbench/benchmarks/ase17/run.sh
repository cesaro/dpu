#!/bin/sh
echo "EXECUTIONG RUN SH $@"
./run.py $@
