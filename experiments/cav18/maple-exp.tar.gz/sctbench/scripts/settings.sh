
export check_mem=0
export enable_djit=0
export sched_race=1
export sched_app=1
export unit_size=1
export seal_after_one=0
export add_races=0

export num_threads=2

export pb=1
export delay_bound=1
export bound=1

export mode=pct
export limit=30
export output=

export out_dir=$ROOT/benchmarks
export run_good=0
export run_bad=1

export cluster=0
export timeout=120
export cpu=0
export seed=0
export start_index=0
export max_threads=4
export max_steps=100
export bug_depth=3

